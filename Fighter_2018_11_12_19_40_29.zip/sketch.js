var players = [];
var gravity = 1;
var moveSpeed = 5;
var ground;

function setup() {
  createCanvas(550, 400);
  ground = createSprite(200, 350, 1000, 20);
	players[0] = new Player();
  players[1] = new Player();
}

function draw() {
  
  //background(220);
  
  updatePlayer();
  drawSprites();
  
}


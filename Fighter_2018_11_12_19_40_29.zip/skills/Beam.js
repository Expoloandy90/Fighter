function Beam(posX, posY){
	fill(102);
  rect(30, 20, 55, 55, 20);
}